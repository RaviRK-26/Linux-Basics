# Introduction

### Course Introduction

  - Take me to the [Video Tutorial](https://kodekloud.com/courses/873064/lectures/17080332)
  
### WAR (Story)

  - Take me to the [Video Tutorial](https://kodekloud.com/courses/873064/lectures/17080232)

### Bob's First Day at Work

  - Take me to the [Video Tutorial](https://kodekloud.com/courses/873064/lectures/17080284)

### Lab Introduction

- Take me to the [Video Tutorial](https://kodekloud.com/courses/873064/lectures/17317208)
