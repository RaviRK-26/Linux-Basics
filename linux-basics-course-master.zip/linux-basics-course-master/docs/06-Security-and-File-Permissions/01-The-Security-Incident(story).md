# Security Incident (story)

  Take me to the[Story](https://kodekloud.com/courses/873064/lectures/17074490)