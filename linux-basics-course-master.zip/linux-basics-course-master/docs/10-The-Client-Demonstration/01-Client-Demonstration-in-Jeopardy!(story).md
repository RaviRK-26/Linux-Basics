# Client Demonstration in Jeopardy!

  Let's hear the [Story](https://kodekloud.com/courses/873064/lectures/17074646)